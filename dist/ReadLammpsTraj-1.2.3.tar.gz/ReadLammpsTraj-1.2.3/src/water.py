# a water data structure
class Water:
	def __init__(self, o, h1, h2):
		self.o = o
		self.h1 = h1
		self.h2 = h2

